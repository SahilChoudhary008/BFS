import turtle as tl
import tkinter.messagebox as tmsg
import numpy as np
import random
import time
import traceback

class BFS:
    def __init__(self, a, b):
        self.x = a
        self.y = b
        self.n = self.x * self.y
        self.matrix = np.zeros((self.n, self.n))

    def adjacency(self, prohibited):
        for i in range(self.n):
            if i not in prohibited:
                for j in range(self.n):
                    if j == i + self.x or j == i - self.x:
                        self.matrix[i][j] = 1
                    if i % self.x == 0:
                        if j == i + 1:
                            self.matrix[i][j] = 1
                    elif (i + 1) % self.x == 0:
                        if j == i - 1:
                            self.matrix[i][j] = 1
                    else:
                        if j == i + 1 or j == i - 1:
                            self.matrix[i][j] = 1

    def calculate_distance(self, m, n):
        self.visited = np.zeros(self.n)
        self.parent = np.zeros(self.n)
        self.visited[m] = 1
        self.queue = [m]
        path_found = False

        while self.queue:
            a = self.queue.pop(0)
            for i in range(self.n):
                if self.matrix[a][i] == 1 and self.visited[i] == 0:
                    self.parent[i] = a
                    self.visited[i] = 1
                    self.queue.append(i)
                    if i == n:
                        path_found = True
                        break
            if path_found:
                break

        if not path_found:
            self.traversed = None
            return

        self.traversed = []
        p = int(self.parent[n])
        self.traversed.append(p)
        while p != m:
            p = int(self.parent[p])
            if p == m:
                break
            self.traversed.append(p)
        self.traversed.reverse()

class Body:
    def __init__(self):
        self.width = 1000
        self.height = 700
        self.screen = tl.Screen()
        self.screen.setup(self.width, self.height)
        self.screen.title("Shortest Path Finder with Bike Animation")
        self.screen.bgcolor("white")
        self.x = 0
        self.y = 0
        self.run = True
        self.dx = 48
        self.dy = 20
        self.step = 20
        self.cy = 110
        self.cx = -470
        self.prohibited = []
        self.rs = []
        self.write()
        self.grid()
        self.allow = True
        self.hs = []
        self.start_pt = 0
        self.end_pt = 959
        self.start = True
        self.end = False
        self.hurdles = False
        self.path_drawer = None
        self.listen_mouse_clicks()
        self.screen.mainloop()

    def main(self):
        b = BFS(self.dx, self.dy)
        b.adjacency(self.prohibited)
        try:
            b.calculate_distance(self.start_pt, self.end_pt)
            for i in self.rs:
                i.goto(1000, 1000)
            self.rs.clear()

            if b.traversed is None:
                raise ValueError("No path found")

            self.animate_bike(b.traversed)
            tmsg.showinfo("Path Found", "Destination reached and Shortest path found.")
            self.erase_all()
        except Exception as e:
            traceback.print_exc()
            tmsg.showinfo("Not Found", "No path found between the start and the end points")

    def animate_bike(self, path):
        self.bike = tl.Turtle()
        self.bike.shape("classic")
        self.bike.shapesize(0.7, 1.2)
        self.bike.color("black")
        self.bike.penup()
        self.bike.speed(1)

        if self.path_drawer:
            self.path_drawer.clear()
            self.path_drawer.hideturtle()
        else:
            self.path_drawer = tl.Turtle()
            self.path_drawer.hideturtle()

        self.path_drawer.penup()
        self.path_drawer.pensize(2)
        self.path_drawer.color("black")
        self.path_drawer.speed(0)

        start_x = self.cx + 20 * (self.start_pt % self.dx)
        start_y = self.cy - 20 * (self.start_pt // self.dx)
        self.bike.goto(start_x, start_y)
        self.path_drawer.goto(start_x, start_y)
        self.path_drawer.pendown()

        for i in path:
            x = self.cx + 20 * (i % self.dx)
            y = self.cy - 20 * (i // self.dx)
            self.bike.goto(x, y)
            self.path_drawer.goto(x, y)
            time.sleep(0.05)

        end_x = self.cx + 20 * (self.end_pt % self.dx)
        end_y = self.cy - 20 * (self.end_pt // self.dx)
        self.bike.goto(end_x, end_y)
        self.path_drawer.goto(end_x, end_y)

    def draw_start(self):
        self.start = True
        self.end = False
        self.hurdles = False

    def draw_end(self):
        self.start = False
        self.end = True
        self.hurdles = False

    def draw_hurdles(self):
        self.start = False
        self.end = False
        self.hurdles = True

    def write(self):
        self.pen = tl.Turtle()
        self.pen.penup()
        self.pen.hideturtle()
        self.pen.speed(0)
        self.pen.color("black")
        self.pen.goto(-480, 300)
        self.pen.write("Shortest Path Finder", False, align="left", font=("arial", 20, "bold"))
        self.pen.goto(-480, 270)
        self.pen.write("Instructions:", False, align="left", font=("arial", 15, "bold"))
        self.pen.goto(-480, 250)
        self.pen.write("a) Press 's' to place Start (Green)", False, align="left", font=("arial", 10, "bold"))
        self.pen.goto(-480, 230)
        self.pen.write("b) Press 'e' to place End (Blue)", False, align="left", font=("arial", 10, "bold"))
        self.pen.goto(-480, 210)
        self.pen.write("c) Press 'h' to place Hurdles (Red)", False, align="left", font=("arial", 10, "bold"))
        self.pen.goto(-480, 190)
        self.pen.write("d) Press 'r' for Random Hurdles", False, align="left", font=("arial", 10, "bold"))
        self.pen.goto(-480, 170)
        self.pen.write("e) Press 'space' to start Animation", False, align="left", font=("arial", 10, "bold"))
        self.pen.goto(-480, 150)
        self.pen.write("f) Press 'o' to clear Grid", False, align="left", font=("arial", 10, "bold"))

    def draw_squares(self, x, y):
        xcor = None
        ycor = None
        for i in range(self.dx):
            if self.cx + 20 * i - 10 < x < self.cx + 20 * i + 10:
                xcor = self.cx + 20 * i
                break
        for j in range(self.dy):
            if self.cy - 20 * j - 10 < y < self.cy - 20 * j + 10:
                ycor = self.cy - 20 * j
                break
        if xcor is not None and ycor is not None:
            loc = j * self.dx + i
            if self.hurdles:
                if loc not in self.prohibited:
                    self.prohibited.append(loc)
                    t = tl.Turtle()
                    t.penup()
                    t.shape("square")
                    t.color("red")
                    t.speed(0)
                    t.goto(xcor, ycor)
                    self.hs.append(t)
            elif self.start:
                self.start_pt = loc
                try:
                    self.st.goto(xcor, ycor)
                except:
                    self.st = tl.Turtle()
                    self.st.penup()
                    self.st.shape("square")
                    self.st.color("green")
                    self.st.speed(0)
                    self.st.goto(xcor, ycor)
            elif self.end:
                self.end_pt = loc
                try:
                    self.et.goto(xcor, ycor)
                except:
                    self.et = tl.Turtle()
                    self.et.penup()
                    self.et.shape("square")
                    self.et.color("blue")
                    self.et.speed(0)
                    self.et.goto(xcor, ycor)

    def erase_all(self):
        try:
            self.et.goto(1000, 1000)
            self.st.goto(1000, 1000)
            for i in self.hs:
                i.goto(1000, 1000)
            self.hs.clear()
            self.prohibited.clear()
            for i in self.rs:
                i.goto(1000, 1000)
            self.rs.clear()
            if hasattr(self, 'bike'):
                self.bike.goto(1000, 1000)
            if self.path_drawer:
                self.path_drawer.clear()
        except:
            pass

    def random_hurdles(self):
        if self.allow:
            for i in range(100):
                loc = random.randint(0, 959)
                if loc not in self.prohibited and loc != self.start_pt and loc != self.end_pt:
                    self.prohibited.append(loc)
                    t = tl.Turtle()
                    t.penup()
                    t.shape("square")
                    t.color("red")
                    t.speed(0)
                    t.goto(self.cx + 20 * (loc % self.dx), self.cy - 20 * (loc // self.dx))
                    self.hs.append(t)
            self.allow = False
        self.allow = True

    def listen_mouse_clicks(self):
        self.screen.listen()
        self.screen.onclick(self.draw_squares)
        self.screen.onkeypress(self.main, "space")
        self.screen.onkeypress(self.draw_start, "s")
        self.screen.onkeypress(self.draw_end, "e")
        self.screen.onkeypress(self.draw_hurdles, "h")
        self.screen.onkeypress(self.erase_all, "o")
        self.screen.onkeypress(self.random_hurdles, "r")

    def grid(self):
        g = tl.Turtle()
        g.color("black")
        g.hideturtle()
        g.speed(0)
        for i in range(21):
            g.penup()
            g.goto(-480, 120 - 20 * i)
            g.pendown()
            g.forward(960)
        for i in range(49):
            g.penup()
            g.goto(-480 + 20 * i, 120)
            g.pendown()
            g.goto(-480 + 20 * i, -280)

if __name__ == "__main__":
    Body()
